#!/bin/bash
# 👑 Ultimate Secure VPN Installer (VLESS + Reality + XTLS + Smart Fallbacks)
# ✅ Designed for AWS EC2 (Ubuntu 20.04/22.04)

set -e

# Check privileges
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root."
  exit 1
fi

echo "🔄 Updating system..."
apt update && apt upgrade -y
apt install -y curl unzip jq qrencode socat iptables ufw net-tools

# Create paths
mkdir -p /usr/local/etc/xray
cd /usr/local/bin

# Download latest Xray-core
echo "⬇️ Installing Xray-core..."
curl -L -o xray.zip https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip
unzip -o xray.zip xray && chmod +x xray && rm -f xray.zip
cd -

# Generate X25519 keys for Reality
echo "🔐 Generating keys..."
cd /usr/local/etc/xray
/usr/local/bin/xray x25519 > keys.txt
privKey=$(grep 'Private key:' keys.txt | cut -d ' ' -f3)
pubKey=$(grep 'Public key:' keys.txt | cut -d ' ' -f3)

# Generate UUID
uuid=$(cat /proc/sys/kernel/random/uuid)

# Build Xray config
cat <<EOF > /usr/local/etc/xray/config.json
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [{ "id": "$uuid", "flow": "xtls-rprx-vision" }],
        "decryption": "none",
        "fallbacks": [
          { "dest": 50001, "xver": 1 },
          { "dest": 50002, "xver": 1 }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "www.cloudflare.com:443",
          "xver": 0,
          "serverNames": ["www.cloudflare.com"],
          "privateKey": "$privKey",
          "shortIds": ["88888888"]
        }
      }
    },
    {
      "port": 50001,
      "protocol": "trojan",
      "settings": {
        "clients": [{ "password": "$uuid" }]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "none"
      }
    },
    {
      "port": 50002,
      "protocol": "shadowsocks",
      "settings": {
        "method": "2022-blake3-aes-128-gcm",
        "password": "$uuid",
        "network": "tcp,udp"
      },
      "streamSettings": {
        "network": "tcp"
      }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "settings": {} }
  ]
}
EOF

# Create systemd service
cat <<EOF > /etc/systemd/system/xray.service
[Unit]
Description=Xray Service
After=network.target

[Service]
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
User=root
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF

# Enable firewall and allow ports
echo "🔐 Configuring firewall..."
ufw allow 443/tcp
ufw allow 50001/tcp
ufw allow 50002/tcp
ufw --force enable

# Start service
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable xray
systemctl restart xray

# Print connection info
ip=$(curl -s https://checkip.amazonaws.com)
echo ""
echo "✅ VPN نصب شد با موفقیت!"
echo "-----------------------------"
echo "🎯 آدرس سرور: $ip"
echo "🆔 UUID: $uuid"
echo "🔑 Reality PublicKey: $pubKey"
echo "🌀 ShortID: 88888888"
echo "🌐 SNI (Fake Domain): www.cloudflare.com"
echo "📦 پورت: 443"
echo "🎯 Trojan Fallback: 50001"
echo "🎯 Shadowsocks Fallback: 50002"
echo ""
echo "📱 برای اتصال، اپ v2rayNG یا NekoRay را نصب کرده و از اطلاعات بالا استفاده کن."
echo "تمام شد ✅"
